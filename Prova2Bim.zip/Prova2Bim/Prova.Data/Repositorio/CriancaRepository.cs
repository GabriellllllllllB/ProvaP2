﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Prova2Bim.Dominio.Entidades;
using Prova2Bim.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Prova2Bim.Data.Repositorio.CriancaRepository;

namespace Prova2Bim.Data.Repositorio
{
    public class CriancaRepository : ICriancaRepository
    {
            private readonly string _connectionString;

            public CriancaRepository(IConfiguration configuration)
            {
                _connectionString = configuration.GetConnectionString("DefaultConnection");
            }

        void ICriancaRepository.Criar(Crianca crianca)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var query = @"INSERT INTO Cartinhas 
                              (Nome, Idade, CPF, Alergia, DesAlergia, NomeMae, TelefonePais) 
                              VALUES 
                              (@Nome, @Idade, @CPF, @Alergia, @DesAlergia, @NomeMae, @TelefonePais)";

                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nome", crianca.Nome);
                command.Parameters.AddWithValue("@Idade", crianca.Idade);
                command.Parameters.AddWithValue("@CPF", crianca.CPF);
                command.Parameters.AddWithValue("@Alergia", crianca.Alergia);
                command.Parameters.AddWithValue("@DesAlergia", crianca.DesAlergia);
                command.Parameters.AddWithValue("@NomeMae", crianca.NomeMae);
                command.Parameters.AddWithValue("@TelefonePais", crianca.TelefonePais);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        void ICriancaRepository.Atualizar(Crianca crianca)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var query = @"INSERT INTO Cartinhas 
                              (Nome, Idade, CPF, Alergia, DesAlergia, NomeMae, TelefonePais) 
                              VALUES 
                              (@Nome, @Idade, @CPF, @Alergia, @DesAlergia, @NomeMae, @TelefonePais)";

                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nome", crianca.Nome);
                command.Parameters.AddWithValue("@Idade", crianca.Idade);
                command.Parameters.AddWithValue("@CPF", crianca.CPF);
                command.Parameters.AddWithValue("@Alergia", crianca.Alergia);
                command.Parameters.AddWithValue("@DesAlergia", crianca.DesAlergia);
                command.Parameters.AddWithValue("@NomeMae", crianca.NomeMae);
                command.Parameters.AddWithValue("@TelefonePais", crianca.TelefonePais);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        List<Crianca> ICriancaRepository.BuscarTodas()
        {
            var lista = new List<Crianca>();

            using (var connection = new SqlConnection(_connectionString))
            {
                var query = "SELECT * FROM Cartinhas";
                var command = new SqlCommand(query, connection);

                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        lista.Add(new Crianca
                        {
                            Nome = (string)reader["Nome"],
                            Idade = (int)reader["Idade"],
                            CPF = reader["CPF"].ToString(),
                            Alergia = (bool)reader["String"],
                            DesAlergia = reader["DesAlergia"].ToString(),
                            NomeMae = reader["NomeMae"].ToString(),
                            TelefonePais = (int)reader["TelefonePais"]
                        });
                    }
                }
            }
            return lista;
        }
        List<Crianca> ICriancaRepository.ListarCpf(Crianca cpf)
        {
            throw new NotImplementedException();
        }
        public Crianca ObterPorCPF(string cpf)
        {
            Crianca crianca = null;

            using (var connection = new SqlConnection(_connectionString))
            {
                var query = "SELECT * FROM Cartinhas WHERE CPF = @CPF";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CPF", cpf);

                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        crianca = new Crianca
                        {
                            Nome = reader["Nome"].ToString(),
                            Idade = (int)reader["Idade"],
                            CPF = reader["CPF"].ToString(),
                            Alergia = (bool)reader["Alergia"],
                            DesAlergia = reader["DesAlergia"].ToString(),
                            NomeMae = reader["NomeMae"].ToString(),
                            TelefonePais = (int)reader["TelefonePais"]
                        };
                    }
                }
            }
            return crianca;
        }

    }


}
