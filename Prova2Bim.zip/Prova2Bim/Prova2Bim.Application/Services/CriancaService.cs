﻿using Prova2Bim.Dominio.Entidades;
using Prova2Bim.Dominio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Prova2Bim.Application.Services.CriancaService;

namespace Prova2Bim.Application.Services
{
    public class CriancaService : ICriancaService
    {
            private readonly ICriancaRepository _criancaRepository;

            public CriancaService(ICriancaRepository criancaRepository)
            {
                _criancaRepository = criancaRepository;
            }

        void ICriancaService.Criar(Crianca crianca)
        {
            var existente = _criancaRepository.ObterPorCPF(crianca.CPF);

            if (existente != null)
                throw new Exception("CPF já existe!");

            _criancaRepository.Criar(crianca);
        }

        void ICriancaService.Atualizar(Crianca crianca)
        {
            _criancaRepository.Atualizar(crianca);
        }

        List<Crianca> ICriancaService.BuscarTodas()
            {
                return _criancaRepository.BuscarTodas();
            }

        List<Crianca> ICriancaService.ListarCpf(Crianca cpf)
        {
            return _criancaRepository.ListarCpf(cpf);
        }
    }
}
