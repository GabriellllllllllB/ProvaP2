﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Prova2Bim.Dominio.Entidades
{
    public class Crianca
    {
        public Crianca() { }

        public Crianca(string nome, int idade, string cpf, bool alergia, string desalergia, string nomemae, int telefonepais)
        {
            Nome = nome;
            Idade = idade;
            CPF = cpf;
            Alergia = alergia;
            DesAlergia = desalergia;
            NomeMae = nomemae;
            TelefonePais = telefonepais;
        }
        public string Nome { get; set; }
        public int Idade { get; set; }
        public string CPF { get; set; }
        public bool Alergia { get; set; }
        public string DesAlergia { get; set; }
        public string NomeMae { get; set; }
        public int TelefonePais { get; set; }
    }
}
