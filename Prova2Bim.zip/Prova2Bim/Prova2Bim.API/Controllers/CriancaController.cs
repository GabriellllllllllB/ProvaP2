﻿using Microsoft.AspNetCore.Mvc;

namespace Prova2Bim.API.Controllers
{
    public class CriancaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
